bin/cake server -H 192.168.0.19 -p 5673
